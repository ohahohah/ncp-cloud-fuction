from pymongo import MongoClient
from pymongo.errors import BulkWriteError 
import json
import requests

def main(args):
    # name 이라는 키워드 인자(argument,arg) 를 가져옴. 없으면 World 로 대신함
    keywords = args.get('keywords', ['KOVO', '여자 배구'])
    # place 라는 키워드 인자(argument,arg) 를 가져옴. 없으면 Naver 로 대신함
    client_id  = args.get('client_id')
    client_secret  = args.get('client_secret')
    db_collection  = args.get('db_collection', 'navernews')

    result = save_news(keywords, client_id, client_secret, db_collection)
    
    return result


def get_news_with_key(keywords,client_id, client_secret):
    '''
    네이버 뉴스 검색 API를 활용하여 검색한 결과를 반환합니다.
    :param list keywords: 검색할 키워드들
    :return API 실행결과- 뉴스 검색결과 리스트 or 에러일 경우, 빈 리스트 반환
    :rtype: list
    '''
    
    news_items = []

    # B. API Request
    # B-1. 준비하기 - 설정값 세팅
    url = 'https://openapi.naver.com/v1/search/news.json'

    for keyword in keywords:
        sort = 'date'  # sim: similarity 유사도, date: 날짜
        display_num = 100
        start_num = 1

        params = {'display': display_num, 'start': start_num,
                'query': keyword.encode('utf-8'), 'sort': sort}
        headers = {'X-Naver-Client-Id': client_id,
                'X-Naver-Client-Secret': client_secret, }

        # B-2. API Request
        r = requests.get(url, headers=headers,  params=params)

        # C. Response 결과에 따라 다르게 처리하기
        # C-2. 결과에 따라 원하는 정보 접근하기

        # 정상적으로 reposponse 결과 받았을 때
        if r.status_code == requests.codes.ok:
            # 변수에 담기
            result_str = r.content.decode('utf-8')

            # json 데이터로 변환
            result = json.loads(result_str)

            # items list 안에 정보 보기
            items = result['items']    
            for item in items:
                originallink = item['originallink']
                link = item['link']
                # print(originallink, link)
                
                # ===naver news 페이지 여부 항목 추가====
                # naver news 페이지가 없다면
                if originallink == link:
                    item['navernews'] = 'N'
                # naver news 페이지가 있다면
                else:
                    item['navernews'] = 'Y'

                # ===photo news 여부 항목 추가====
                # naver news link url에 oid=001 가 들어가 있음
                if 'oid=001' in item['link']:
                    item['photoNews'] = 'Y'
                else:
                    item['photoNews'] = 'N'

                news_items.append(item)

        # response 결과가 오류가 난다면
        else:
            # 두 에러 정보 같이 확인하기
            result = {'Error': r.status_code, 'Error_Message': r.content.decode('utf-8')}
            print(result)

    return items

def save_news(keywords, client_id, client_secret, db_collection):
    '''
    네이버 검색 -news API 수집 결과를 DB 에 저장합니다.
    :param list keywords: 검색할 키워드들
    :param str client_id: 뉴스 검색 API 인증 id
    :param str client_secret: 뉴스 검색 API 인증 패스워드(secret)
    :param str db_collection: 뉴스 저장할 db collection 이름
    :return db_result : 검색 결과를 DB 저장결과
    :rtype: dict
    '''
    db_result = {'result': 'success'}

    # Connect to MongoDB server
    client = MongoClient('mongodb://kkk:kkkk@101.101.218.60', 27017)
    db = client['likelion']
    collection = db[db_collection]

    # unique key : link / link 를 유일하게
    collection.create_index([('link',1)],unique=True)

    docs = get_news_with_key(keywords,client_id, client_secret)

    try:
        collection.insert_many(docs, ordered=False)
    except BulkWriteError as bwe:
        # print('중복 데이터 발생:', bwe.details)
        # print('중복 데이터 발생. 중복 저장하지 않음')
        db_result['result'] = 'Insert and Ignore duplicated data'
    
    return db_result

